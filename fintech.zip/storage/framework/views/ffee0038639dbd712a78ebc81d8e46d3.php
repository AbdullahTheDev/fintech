<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Questionnaire</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }

        .container {
            padding: 20px;
        }

        .mb-3 {
            margin-bottom: 15px;
        }

        h4 {
            margin-top: 20px;
            margin-bottom: 10px;
        }

        p {
            margin: 0;
        }

        strong {
            font-weight: bold;
        }

        img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>

<body>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $title = str_replace('_', ' ', $key);
        ?>
        <p><?php echo e(ucfirst($title)); ?> <strong><?php echo e($dt); ?></strong></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h4>Reference Images(s)</h4>
    <br/>
    <br/>
    <?php if(!empty($filePaths)): ?>
        <?php $__currentLoopData = $filePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="data:image/png;base64,<?php echo base64_encode(file_get_contents(base_path('public/' . $img))); ?>" style="width: 250px; margin: 10px;">
            <a href="<?php echo e(asset($img)); ?>">Image</a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    

</body>

</html>
<?php /**PATH C:\Users\AL ETAAR\fintech\resources\views/pdf/pdf_template.blade.php ENDPATH**/ ?>