<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h6 style="text-align: right; color: #2c3e50">ID: <?php echo e($customId); ?></h6>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $title = str_replace('_', ' ', $key);
    ?>
        <p><?php echo e(ucfirst($title)); ?> <strong><?php echo e($dt); ?></strong></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h4>Reference Logo(s)</h4>
    <?php $__currentLoopData = $filePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e(asset($img)); ?>" style="width: 250px; margin: 10px;" alt="">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="my-3">
        <h4>PDF download URL</h4>
        <a href="<?php echo e(route('search.view', $customId)); ?>">Click here to download your PDF brief</a>
    </div>
</body>

</html>
<?php /**PATH C:\Users\AL ETAAR\fintech\resources\views/email/brief_form.blade.php ENDPATH**/ ?>